<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Case_status extends Model
{
    protected $guarded = [];
}
